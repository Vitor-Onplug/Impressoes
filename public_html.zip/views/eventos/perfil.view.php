<?php 
if(!defined('ABSPATH')) exit; 

$modelo->getEvento(chk_array($parametros, 1));

$contratados = $modeloEventoContratacoes->getContratacoes(null, null, chk_array($parametros, 1));

if(!empty($_POST['destino']) && !empty($_POST['mensagem'])){
	$mensagens = $modeloMensagens->validarFormMensagem($_POST['destino'], $_POST['mensagem']); 
}

$valorImposto = 0;
?>
        <div class="content-wrapper">
            <section class="content-header">
                <h1>Perfil do Evento<small>&nbsp;</small></h1>
                
				<ol class="breadcrumb">
                    <li><a href="<?php echo HOME_URI; ?>"><i class="fa fa-dashboard"></i> Painel</a></li>
                    <li><a href="<?php echo HOME_URI; ?>/eventos">Eventos</a></li>
                    <li class="active"><a href="<?php echo HOME_URI; ?>/eventos/index/perfil/<?php echo chk_array($parametros, 1); ?>">Perfil do Evento</a></li>
                </ol>
            </section>

            <section class="content">
                <div class="row">
                    <div class="col-md-12">
						<div class="info-perfil">
							<span class="info-perfil-icon bg-aqua"><img class="" src="<?php echo HOME_URI;?>/utils/thumbnail/?width=445&height=250&imagem=<?php echo $modelo->getAvatar(chk_array($parametros, 1)); ?>" alt="<?php echo htmlentities(chk_array($modelo->form_data, 'evento')); ?>"></span>

							<div class="info-perfil-content">
								<span class="info-perfil-text"><?php echo htmlentities(chk_array($modelo->form_data, 'dataInicioFim')); ?></span>
								<span class="info-perfil-number"><?php echo htmlentities(chk_array($modelo->form_data, 'evento')); ?></span>
								<span class="info-perfil-text"><?php echo htmlentities(chk_array($modelo->form_data, 'categoria')); ?></span>
								<span class="info-perfil-text"><a href="<?php echo HOME_URI; ?>/clientes/index/perfil/<?php echo htmlentities(chk_array($modelo->form_data, 'idCliente')); ?>"><?php echo htmlentities(chk_array($modelo->form_data, 'nomeFantasia')); ?></a></a></span>
							</div>
						</div>
						
						<div class="row">
							<?php
							$fasesEvento = $modeloEventoFases->getFases(chk_array($parametros, 1)); 
							foreach($fasesEvento AS $dadosFasesEventos):
							?>
							<div class="col-md-3">
								<div class="callout" style="background-color: <?php echo $dadosFasesEventos['cor']; ?>; color: #fff !important;">
									<h4 class="mb-x0 text-center">
										<i class="fa fa-check-circle-o"></i> <?php echo $dadosFasesEventos['fase']; ?>
										<br>
										<?php echo implode("/", array_reverse(explode("-", $dadosFasesEventos['dataInicio']))) . " - " . implode("/", array_reverse(explode("-", $dadosFasesEventos['dataFim']))); ?>
									</h4>
								</div>
							</div>
							<?php
							endforeach; 
							?>
						</div>
						
						<div class="row">
							<?php
							$lideresEvento = $modeloEventoLideres->getLideres(chk_array($parametros, 1)); 
							if(count($lideresEvento) > 0){
							?>
								<?php foreach($lideresEvento AS $dadosLideresEventos): ?>
									<div class="col-md-3">
										<div class="box box-widget widget-user-2">
											<div class="widget-user-header bg-red">
												<div class="widget-user-image">
													<img class="img-circle" src="<?php echo HOME_URI;?>/utils/thumbnail/?width=128&height=128&imagem=<?php echo $modeloUsuarios->getAvatar(null, $dadosLideresEventos['idLider']); ?>" alt="<?php echo $dadosLideresEventos['nome']; ?>">
												</div>
												<h4 class="widget-user-username"><?php echo $dadosLideresEventos['apelido']; ?></h4>
												<h5 class="widget-user-desc"><?php echo $dadosLideresEventos['lideranca']; ?></h5>
											</div>
										</div>
									</div>
								<?php endforeach; ?>
							<?php } ?>
						</div>
						<?php if($this->check_permissions('evento-financeiro', $this->userdata['modulo'])){ ?>
                        <div class="box box-widget widget-user-2">
                            <div class="box-footer no-padding">
                                <ul class="nav nav-stacked">
									<?php if($this->userdata['idPermissao'] < 3){ ?>
									<li><a href="javascript:void(0)">Verba do Contrato <span class="pull-right badge bg-red">R$ <?php echo number_format(chk_array($modelo->form_data, 'valorContrato'), 2, ',', '.'); ?></span></a></li>
									<li><a href="javascript:void(0)">Imposto (Ilustrativo) <span class="pull-right badge bg-red">R$ <?php echo number_format($valorImposto = ((chk_array($modelo->form_data, 'valorContrato')/100) * chk_array($modelo->form_data, 'imposto')), 2, ',', '.'); ?></span></a></li>
									<?php } ?>
								
                                    <li><a href="javascript:void(0)">Verba Evento <span class="pull-right badge bg-red">R$ <?php echo number_format(chk_array($modelo->form_data, 'verba'), 2, ',', '.'); ?></span></a></li>
									<li><a href="javascript:void(0)">Verba Escritório <span class="pull-right badge bg-red">R$ -<?php echo number_format(chk_array($modelo->form_data, 'escritorio'), 2, ',', '.'); ?></span></a></li>
									
									<?php
									$liderancasEvento = $modeloEventoLideres->getLideres(chk_array($parametros, 1)); 
									$totalLideranca = 0;
									if(count($lideresEvento) > 0){
									?>
										<?php foreach($liderancasEvento AS $dadosLiderancasEventos): ?>
											<?php $totalLideranca += $dadosLiderancasEventos['verba']; ?>
											<li>
												<a href="javascript:void(0)">
													(<?php echo $dadosLiderancasEventos['apelido']; ?>) <?php echo $dadosLiderancasEventos['lideranca']; ?>
													<span class="pull-right  badge bg-red">R$ <?php echo number_format($dadosLiderancasEventos['verba'], 2, ',', '.'); ?></span>
													<span class="pull-right badge bg-red mr-x1">R$ <?php echo number_format($modeloEventoFinanceiro->getTotalOperacaoLider(chk_array($parametros, 1), "Débito", $dadosLiderancasEventos['idLider']), 2, ',', '.'); ?>
													</span>
												</a>
											</li>
										<?php endforeach; ?>
									<?php } ?>
									
									<li>
										<a href="<?php echo HOME_URI; ?>/eventos/index/contratacoes/<?php echo chk_array($parametros, 1); ?>">
											Contratados <span class="pull-right badge bg-red"><?php echo count($contratados); ?></span>
											<span class="pull-right badge bg-red mr-x1">R$ 
											<?php
											$valorContratacoes = 0;

											foreach($contratados AS $dadosContratados): 
												$quantidadeDias = diff_datas(implode("/", array_reverse(explode("-", $dadosContratados['dataInicio']))), implode("/", array_reverse(explode("-", $dadosContratados['dataFim'])))) + 1;
												
												$faltas = $modeloEventoContratacoesFaltas->getFaltas(null, $dadosContratados["id"]);
												$quantidadeFaltas = count($faltas);
												
												$valorContratacoes += ($quantidadeDias - $quantidadeFaltas) * $dadosContratados['valor'];
											endforeach;
											
											echo number_format($valorContratacoes, 2, ',', '.');
											?>
											</span>
										</a>
									</li>
                                    <li><a href="javascript:void(0)">Gastos <span class="pull-right badge bg-red">R$ <?php echo number_format($gastos = $modeloEventoFinanceiro->getTotalOperacao(chk_array($parametros, 1), "Débito"), 2, ',', '.'); ?></span></a></li>
                                    <li><a href="javascript:void(0)">Consumo atual <span class="pull-right badge bg-red">R$ <?php echo number_format(($consumoAtual = (chk_array($modelo->form_data, 'escritorio') + $totalLideranca + $valorContratacoes + $gastos)), 2, ',', '.'); ?></span></a></li>
									<?php $verbaRestante = (chk_array($modelo->form_data, 'verba') - $consumoAtual); ?>
									<li><a href="javascript:void(0)">Restante <span class="pull-right badge <?php if($verbaRestante < 0){ echo'bg-orange'; }else{ echo'bg-green'; } ?>">R$ <?php echo number_format($verbaRestante, 2, ',', '.'); ?></span></a></li>
                                </ul>
                            </div>
                        </div>
						<?php } ?>
						
						<?php
						if(count($contratados) > 0){
						?>
						<div class="box box-danger collapsed-box">
                            <div class="box-header with-border" data-widget="collapse">
								<i class="fa fa-users"></i>
                                <h3 class="box-title">Equipe de Contratados</h3>
								
								<?php if($this->check_permissions('evento-financeiro', $this->userdata['modulo'])){ ?>
								<span class="pull-right badge bg-red">Total / evento - R$ <?php echo number_format($valorContratacoes, 2, ',', '.'); ?></span>
								<?php } ?>
                            </div>
							
                            <div class="box-body table-responsive">
                                <table id="table" class="table table-hover table-bordered table-striped ">
                                    <thead>
                                        <tr>
                                            <th>Período</th>
											<th>Pagamento</th>
											<th>Nome</th>
											<th>Função</th>
											<th style="width: 100px;">Diaria</th>
											<th>Dias</th>
											<th>Faltas</th>
											<th style="width: 100px;">Total</th>
											<th>Pontuação</th>
											<th>Status</th>
											<?php if($this->userdata['idPermissao'] < 4){ ?>
											<th style="width: 140px;">Opções</th>
											<?php } ?>
                                        </tr>
                                    </thead>
									
                                    <tbody>
										<?php 
										foreach($contratados AS $dadosContratados): 
											if($this->userdata['idPermissao'] < 4 || ($this->userdata['idPermissao'] == 4 && $this->userdata['id'] == $dadosContratados["idPessoa"])){
												$faltas = $modeloEventoContratacoesFaltas->getFaltas(null, $dadosContratados["id"]);
										?>
										<tr>
											<td><?php echo implode("/", array_reverse(explode("-", $dadosContratados['dataInicio']))); ?> - <?php echo implode("/", array_reverse(explode("-", $dadosContratados['dataFim']))); ?></td>
											<td><?php if($dadosContratados["pago"] == "T"){ echo implode("/", array_reverse(explode("-", $dadosContratados['dataPagamento']))); }else{ echo"Pendente"; } ?></td>
                                            <td><a href="<?php echo HOME_URI; ?>/usuarios/index/perfil/<?php echo $dadosContratados["idUsuario"]; ?>"><?php echo $dadosContratados["nome"]; ?> <?php echo $dadosContratados["sobrenome"]; ?></a></td>
											<td><?php echo $dadosContratados["funcao"]; ?></td>
                                            <td>R$ <?php echo number_format($dadosContratados['valor'], 2, ',', '.'); ?></td>
											<td><?php echo $quantidadeDias = diff_datas(implode("/", array_reverse(explode("-", $dadosContratados['dataInicio']))), implode("/", array_reverse(explode("-", $dadosContratados['dataFim'])))) + 1; ?></td>
											<td><?php echo $quantidadeFaltas = count($faltas); ?></td>
                                            <td>R$ <?php echo number_format((($quantidadeDias - $quantidadeFaltas) * $dadosContratados['valor']), 2, ',', '.'); ?></td>
											<td>
												<?php
												$pontuacao = $modeloUsuarios->getPontuacao($dadosContratados["idPessoa"]);
												
												if($pontuacao["media"] < 0.5){
													echo'<i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i>';
												}elseif($pontuacao["media"] < 1){
													echo'<i class="fa fa-star-half-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i>';
												}elseif($pontuacao["media"] < 1.5){
													echo'<i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i>';
												}elseif($pontuacao["media"] < 2){
													echo'<i class="fa fa-star"></i><i class="fa fa-star-half-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i>';
												}elseif($pontuacao["media"] < 2.5){
													echo'<i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i>';
												}elseif($pontuacao["media"] < 3){
													echo'<i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i>';
												}elseif($pontuacao["media"] < 3.5){
													echo'<i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i><i class="fa fa-star-o"></i>';
												}elseif($pontuacao["media"] < 4){
													echo'<i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i><i class="fa fa-star-o"></i>';
												}elseif($pontuacao["media"] < 4.5){
													echo'<i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-o"></i>';
												}elseif($pontuacao["media"] < 5){
													echo'<i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star-half-o"></i>';
												}else{
													echo'<i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i><i class="fa fa-star"></i>';
												}
												?>
											</td>
											<td><?php if($dadosContratados['dispensado'] == 'T'){ echo'Demitido'; }else{ echo'Ativo'; } ?></td>
											<?php if($this->userdata['idPermissao'] < 4){ ?>
											<td>
												<?php if($this->check_permissions('evento-faltas', $this->userdata['modulo'])){?>
												<a href="<?php echo HOME_URI; ?>/eventos/index/faltas/<?php echo chk_array($parametros, 1); ?>" class="icon-tab" title="Faltas"><i class="fa fa-calendar-times-o  fa-lg"></i></a>&nbsp; &nbsp; &nbsp;
												<?php } ?>
												
												<?php if($this->check_permissions('evento-demissao', $this->userdata['modulo'])){?>
												<a href="<?php echo HOME_URI; ?>/eventos/index/demissao/<?php echo $dadosContratados["id"]; ?>" class="icon-tab" title="Demitir"><i class="fa fa-user-times fa-lg"></i></a>&nbsp; &nbsp; &nbsp;
												<?php } ?>
												
												<?php if($this->check_permissions('evento-pagamento', $this->userdata['modulo'])){?>
												<a href="<?php echo HOME_URI; ?>/eventos/index/pagamento/<?php echo $dadosContratados["id"]; ?>" class="icon-tab" title="Pagamento"><i class="fa fa-money fa-lg"></i></a>&nbsp; &nbsp; &nbsp;
												<?php } ?>
											</td>
											<?php } ?>
                                        </tr>
										<?php 
											}
										endforeach; 
										?>
									</tbody>
                                </table>
                            </div>
                        </div>
						<?php
						}
						?>
						
						<?php
						if($this->check_permissions('evento-financeiro', $this->userdata['modulo'])){
							$operacoesFinanceiro = $modeloEventoFinanceiro->getOperacoes(chk_array($parametros, 1));
							if(count($operacoesFinanceiro) > 0){
						?>
						<div class="box box-danger collapsed-box">
                            <div class="box-header with-border" data-widget="collapse">
								<i class="fa fa-calculator"></i>
                                <h3 class="box-title">Gastos do Evento</h3>
								<?php if($this->userdata['idPermissao'] < 3){ ?>
								<span class="pull-right badge bg-red">Gastos - R$ <?php echo number_format($gastos, 2, ',', '.'); ?></span>
								<span class="pull-right badge bg-red mr-x1">Verba - R$ <?php echo number_format(chk_array($modelo->form_data, 'verba'), 2, ',', '.'); ?></span>
								<?php 
								}else{ 
									$modeloEventoLideres->getLider(null, chk_array($parametros, 1), $this->userdata['id']);
								?>
								<span class="pull-right badge bg-red">Gastos - R$ <?php echo number_format($modeloEventoFinanceiro->getTotalOperacaoLider(chk_array($parametros, 1), 'Débito', $this->userdata['id']), 2, ',', '.'); ?></span>
								<span class="pull-right badge bg-red mr-x1">Verba - R$ <?php echo number_format(chk_array($modeloEventoLideres->form_data, 'verba'), 2, ',', '.'); ?></span>
								<?php } ?>
                            </div>
							
                            <div class="box-body table-responsive">
                                <table id="table" class="table table-hover table-bordered table-striped ">
                                    <thead>
                                        <tr>
                                            <th>Data</th>
											<th>Descrição</th>
											<th>Quant.</th>
											<th>Valor Un.</th>
											<th>Total</th>
											<th>Comprovante</th>
											<th>Gerente</th>
											<th>Vinculado</th>
											<th>Opções</th>
                                        </tr>
                                    </thead>

                                    <tbody>
										<?php foreach($operacoesFinanceiro AS $dadosOperacoes): ?>
										<tr>
                                            <td><?php echo implode("/", array_reverse(explode("-", $dadosOperacoes['data']))); ?></td>
											<td><?php echo $dadosOperacoes['descricao']; ?></td>
                                            <td><?php echo $quantidadeOperacao = $dadosOperacoes['quantidade']; ?></td>
											<td>R$ <?php echo number_format($dadosOperacoes['valor'], 2, ',', '.'); ?></td>
                                            <td>R$ <?php echo number_format(($dadosOperacoes['valor'] * $quantidadeOperacao), 2, ',', '.'); ?></td>
											<td>
												<a href="<?php echo HOME_URI;?>/<?php echo $modeloEventoFinanceiro->getComprovante($dadosOperacoes['id'], chk_array($this->parametros, 1)); ?>" target="_blank" class="icon-tab" title="Comprovante"><i class="fa fa-sticky-note-o fa-lg"></i></a>
											</td>
											<td><a href="<?php echo HOME_URI; ?>/usuarios/index/perfil/<?php echo $dadosOperacoes["cadastroPessoa"]; ?>"><?php echo $dadosOperacoes["cadastroNome"]; ?> <?php echo $dadosOperacoes["cadastroSobrenome"]; ?></a></td>
											<td><a href="<?php echo HOME_URI; ?>/usuarios/index/perfil/<?php echo $dadosOperacoes["idUsuario"]; ?>"><?php echo $dadosOperacoes["nome"]; ?> <?php echo $dadosOperacoes["sobrenome"]; ?></a></td>
											
											<td>
												<?php if($this->check_permissions('evento-financeiro-editar', $this->userdata['modulo'])){?>
												<a href="<?php echo HOME_URI;?>/eventos/index/perfil/<?php echo chk_array($parametros, 1); ?>/editar/<?php echo $dadosOperacoes['id']; ?>" class="icon-tab" title="Editar"><i class="fa fa-pencil-square-o fa-lg"></i></a>
												<?php } ?>
											</td>
                                        </tr>
										<?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
						<?php
							}
						}
						?>
						
						<?php
						if($this->check_permissions('evento-financeiro-adicionar', $this->userdata['modulo']) || $this->check_permissions('evento-financeiro-editar', $this->userdata['modulo'])){
							$modeloEventoFinanceiro->validarFormOperacao();
							
							if(chk_array($this->parametros, 2) == 'editar' && is_numeric(chk_array($this->parametros, 3))){
								$modeloEventoFinanceiro->getOperacao(chk_array($this->parametros, 3), chk_array($this->parametros, 1));
								
								$dataHoraCriacao = explode(" ", chk_array($modeloEventoFinanceiro->form_data, 'dataCriacao'));
								$dataCriacao = explode("-", $dataHoraCriacao[0]);
								
								$modeloEventoFinanceiro->form_data['midia'] = "midia/financeiro/" . $dataCriacao[0] . "/" . $dataCriacao[1] . "/" . $dataCriacao[2] . "/" . chk_array($modeloEventoFinanceiro->form_data, 'id');
							}else{
								if(empty(chk_array($modeloEventoFinanceiro->form_data, 'midia'))){
									$diretorioTemporario = md5(uniqid(time()));
									$modeloEventoFinanceiro->form_data['midia'] = "temp/financeiro/" . $diretorioTemporario;
								}
							}
							
							$_SESSION['comprovanteFinanceiro'] = $modeloEventoFinanceiro->form_data['midia'];
						?>
						<div class="box box-danger collapsed-box">
                            <div class="box-header with-border <?php if(empty($modeloEventoFinanceiro->form_msg)){ echo'collapsed in'; } ?>" data-widget="collapse">
								<i class="fa fa-dollar"></i>
                                <h3 class="box-title"><?php if(chk_array($this->parametros, 2) == 'editar' && is_numeric(chk_array($this->parametros, 3))){ echo'Editar'; }else{ echo'Adicionar'; } ?> Gasto</h3>
                            </div>
							
							<form role="form" action="" method="POST" enctype="multipart/form-data">
								<input type="hidden" name="diretorioMidia" value="<?php echo chk_array($modeloEventoFinanceiro->form_data, 'midia'); ?>">
								<input type="hidden" name="tipo" value="Débito">
								
								<div class="box-body">
									<?php 
									echo $modeloEventoFinanceiro->form_msg;
									?>
									
									<div class="row">
										<div class="col-md-2">
											<div class="form-group">
												<div class="input-group date">
													<div class="input-group-addon">
														<i class="fa fa-calendar"></i>
													</div>
													<input type="text" class="form-control pull-right datepicker" id="data" name="data" placeholder="" value="<?php if(!empty(chk_array($modeloEventoFinanceiro->form_data, 'data'))){ echo implode("/", array_reverse(explode("-", chk_array($modeloEventoFinanceiro->form_data, 'data')))); } ?>">
												</div>
											</div>
										</div>
										<div class="col-md-6">
											<div class="form-group">
												<input type="text" class="form-control" name="descricao" id="descricao" placeholder="Descrição do Gasto" value="<?php echo chk_array($modeloEventoFinanceiro->form_data, 'descricao'); ?>">
											</div>
										</div>
										
										<div class="col-md-2">
											<div class="form-group">
												<input type="text" name="valor" id="valor" class="form-control money" placeholder="Valor Unit." value="<?php echo chk_array($modeloEventoFinanceiro->form_data, 'valor'); ?>">
											</div>
										</div>
										
										<div class="col-md-2">
											<div class="form-group">
												<input type="number" min="1" step="1" name="quantidade" id="quantidade" class="form-control" placeholder="Qtd." value="<?php echo chk_array($modeloEventoFinanceiro->form_data, 'quantidade'); ?>">
											</div>
										</div>
									</div>
									
									 <div class="row">
										<?php if($this->userdata['idPermissao'] < 3){ ?>
										<div class="col-md-6">
											<div class="form-group">
												<select class="form-control select2" name="idCadastro" id="idCadastro" style="width: 100%;">
													<option value="">Responsável</option>
													<optgroup label="Escritório">
														<option <?php if(htmlentities(chk_array($modeloEventoFinanceiro->form_data, 'idCadastro')) == $this->userdata['id']){ echo'selected'; } ?> value="<?php echo $this->userdata['id']; ?>" ><?php echo $this->userdata['apelido'] ?></option>
													</optgroup>
													<optgroup label="Gerentes">
														<?php
														foreach($lideresEvento AS $dadosLideresEventos): 
															echo"<option value='" . $dadosLideresEventos['idLider'] . "' ";
															if(htmlentities(chk_array($modeloEventoFinanceiro->form_data, 'idCadastro')) == $dadosContratados['idLider']){ echo'selected'; }
															echo">(" . $dadosLideresEventos['lideranca'] . ") " . $dadosLideresEventos['nome'] . " " . $dadosLideresEventos['sobrenome'] . "</option>";
														endforeach;
														?>
													</optgroup>
												</select>
											</div>
										</div>
										<?php } ?>
									 
										<div class="col-md-6">
											<div class="form-group">
												<select class="form-control select2" name="idPessoa" id="idPessoa" style="width: 100%;">
													<option value="">Pessoa Vinculada</option>
													<optgroup label="Gerentes">
														<?php
														foreach($lideresEvento AS $dadosLideresEventos): 
															echo"<option value='" . $dadosLideresEventos['idLider'] . "' ";
															if(htmlentities(chk_array($modeloEventoFinanceiro->form_data, 'idPessoa')) == $dadosContratados['idLider']){ echo'selected'; }
															echo">(" . $dadosLideresEventos['lideranca'] . ") " . $dadosLideresEventos['nome'] . " " . $dadosLideresEventos['sobrenome'] . "</option>";
														endforeach;
														?>
													</optgroup>
													<optgroup label="Contratados">
														<?php
														foreach($contratados AS $dadosContratados): 
															echo"<option value='" . $dadosContratados['idPessoa'] . "' ";
															if(htmlentities(chk_array($modeloEventoFinanceiro->form_data, 'idPessoa')) == $dadosContratados['idPessoa']){ echo'selected'; }
															echo">(" . $dadosContratados['funcao'] . ") " . $dadosContratados['nome'] . " " . $dadosContratados['sobrenome'] . "</option>";
														endforeach;
														?>
													</optgroup>
												</select>
											</div>
										</div>

										
									</div>
									
									<div class="row">
										<div class="col-md-6">
											<div class="form-group">
												<textarea class="textarea" name="observacao" id="observacao" placeholder="Observações" style="width: 100%; height: 75px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?php echo chk_array($modeloEventoFinanceiro->form_data, 'observacao'); ?></textarea>
											</div>
										</div>
										
										<div class="col-md-6">
											<div class="form-group">
												<label for="comprovante">Adicionar Comprovante</label>
												<div id="comprovante">Enviar</div>
											</div>
										</div>
									</div>
								</div>
								
								<div class="box-footer clearfix">
									<button type="submit" class="btn btn-primary"><i class="fa fa-dollar"></i> Salvar</button>
								</div>
							</form>
                        </div>
						<?php } ?>
						
						<div class="box box-danger collapsed-box">
                            <div class="box-header with-border" data-widget="collapse">
								<i class="fa fa-envelope"></i>
                                <h3 class="box-title">Mensagem</h3>
                            </div>
							
							<form role="form" action="" method="POST" enctype="multipart/form-data">
								<div class="box-body">
									<?php 
									echo $modeloMensagens->form_msg;
									?>
									
									 <div class="form-group">
										<select class="form-control select2" name="destino" id="destino" style="width: 100%;">
											<option value="">Para quem?</option>
												<optgroup label="Gerentes">
													<?php
													foreach($lideresEvento AS $dadosLideresEventos): 
														echo"<option value='" . $dadosLideresEventos['idLider'] . "' ";
														if(htmlentities(chk_array($modeloEventoFinanceiro->form_data, 'idPessoa')) == $dadosLideresEventos['idLider']){ echo'selected'; }
														echo">(" . $dadosLideresEventos['lideranca'] . ") " . $dadosLideresEventos['nome'] . " " . $dadosLideresEventos['sobrenome'] . "</option>";
													endforeach;
													?>
												</optgroup>
												<optgroup label="Contratados">
													<?php
													foreach($contratados AS $dadosContratados): 
														echo"<option value='" . $dadosContratados['idPessoa'] . "' ";
														if(htmlentities(chk_array($modeloEventoFinanceiro->form_data, 'idPessoa')) == $dadosContratados['idPessoa']){ echo'selected'; }
														echo">(" . $dadosContratados['funcao'] . ") " . $dadosContratados['nome'] . " " . $dadosContratados['sobrenome'] . "</option>";
													endforeach;
													?>
												</optgroup>
										</select>
									</div>
								
									<div>
										<textarea class="textarea" placeholder="Mensagem" name="mensagem" id="mensagem" style="width: 100%; height: 75px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"></textarea>
									</div>
								</div>
								
								<div class="box-footer clearfix">
									<button type="submit" class="pull-right btn btn-default">Enviar <i class="fa fa-arrow-circle-right"></i></button>
								</div>
							</form>
                        </div>
					</div>
					
                    <div class="col-md-12">
					<?php if($this->check_permissions('evento-contatos', $this->userdata['modulo'])){ ?>
						<div class="info-box">
                            <span class="info-box-icon bg-red"><i class="fa fa-user"></i></span>

                            <div class="info-box-content">
                                <span class="info-box-text">RESPONSÁVEL: <?php echo htmlentities(chk_array($modelo->form_data, 'nome')); ?> <?php echo htmlentities(chk_array($modelo->form_data, 'sobrenome')); ?></span>
								<span class="info-box-text">TELEFONE: <?php echo chk_array($this->ClasseTelefone->getTelefone(chk_array($modelo->form_data, 'idCliente'), 'Fixo'), 'telefone'); ?></span>
								<span class="info-box-text">CELULAR: <?php echo chk_array($this->ClasseTelefone->getTelefone(chk_array($modelo->form_data, 'idCliente'), 'Celular'), 'telefone'); ?></span>
								<span class="info-box-text">EMAIL: <?php echo htmlentities(chk_array($modelo->form_data, 'email')); ?></span>
                            </div>
                        </div>
						
						<?php
							$contatos = $modeloClientesContatos ->getContatos(chk_array($parametros, 1));
							if(count($contatos) > 0){
						?>
								<?php 
								foreach($contatos AS $dadosContatos): 
								?>
								<div class="info-box">
									<span class="info-box-icon bg-red"><i class="fa fa-user"></i></span>

									<div class="info-box-content">
										<span class="info-box-text">CONTATO: <?php echo $dadosContatos["nome"]; ?> <?php echo $dadosContatos["sobrenome"]; ?></span>
										<span class="info-box-text">TELEFONE: <?php echo chk_array($this->ClasseTelefone->getTelefone($dadosContatos['idContato'], 'Fixo'), 'telefone'); ?></span>
										<span class="info-box-text">CELULAR: <?php echo chk_array($this->ClasseTelefone->getTelefone($dadosContatos['idContato'], 'Celular'), 'telefone'); ?></span>
										<span class="info-box-text">EMAIL: <?php echo $dadosContatos["email"]; ?></span>
									</div>
								</div>
								<?php endforeach; ?>
							<?php } ?>
						<?php } ?>
						
                        <div class="box box-primary ">
                            <div class="box-header with-border">
								<i class="fa fa-map-marker"></i>
                                <h3 class="box-title">Google Map</h3>
                            </div>

							<div class="box-body">
								<script type="text/javascript" src="//maps.googleapis.com/maps/api/js?key=AIzaSyDqITRk0Rt9D7RsFR3spL9r_HiEupKEcY4&amp;"></script>
								<script type="text/javascript">
									var map;
									var infoWindow;

									var markersData = [
										<?php
										echo"
										{
											lat: " . chk_array($modelo->form_data, 'latitude') . ",
											lng: " . chk_array($modelo->form_data, 'longitude') . ",
											cep: '" . chk_array($modelo->form_data, 'cep') . "',
											endereco: '" . chk_array($modelo->form_data, 'logradouro') . ", " . chk_array($modelo->form_data, 'numero') . "',
											bairro: '" . chk_array($modelo->form_data, 'bairro') . "',
											cidade: '" . chk_array($modelo->form_data, 'cidade') . "',
											estado: '" . chk_array($modelo->form_data, 'estado') . "'
										}";
										
										?>
									];
									
									function createMarker(latlng, cep, endereco, bairro, cidade, estado){
									   var marker = new google.maps.Marker({
										  map: map,
										  position: latlng
									   });
									   
									   var iwContent = '<div>' + '<div>' + endereco + '<br />' + bairro + '<br />' + cidade + '/' + estado + '<br />' +  cep + '</div></div>';

									   infoWindow.setContent(iwContent);
									   
									   google.maps.event.addListener(marker, 'click', function() {
											infoWindow.open(map, marker);
									   });
									   
									   infoWindow.open(map, marker);
									   
									   map.setZoom(18);
									}

									function displayMarkers(){
										var bounds = new google.maps.LatLngBounds();
										for (var i = 0; i < markersData.length; i++){
											var latlng = new google.maps.LatLng(markersData[i].lat, markersData[i].lng);
											var cep = markersData[i].cep;
											var endereco = markersData[i].endereco;
											var bairro = markersData[i].bairro;
											var cidade = markersData[i].cidade;
											var estado = markersData[i].estado;

											createMarker(latlng, cep, endereco, bairro, cidade, estado);
											bounds.extend(latlng);  
										}
									}
									
									function initialize() {
									   var mapOptions = {
										  zoom: 18,
										  center: new google.maps.LatLng(<?php echo chk_array($modelo->form_data, 'latitude'); ?>,<?php echo chk_array($modelo->form_data, 'longitude'); ?>),
										  mapTypeId: 'roadmap',
									   };

									   map = new google.maps.Map(document.getElementById('mapa'), mapOptions);

									   infoWindow = new google.maps.InfoWindow();

									   google.maps.event.addListener(map, 'click', function() {
										  infoWindow.close();
									   });

									   displayMarkers();
									}
									
									google.maps.event.addDomListener(window, 'load', initialize);
								</script>
								
								<div id="mapa" style="width: 100%; height: 600px;"></div>
							</div> 
                        </div>
						
						<div class="box-footer">
							<div class="col-md-4 pl-x0">
								<?php if($this->check_permissions('evento-editar', $this->userdata['modulo'])){ ?>
								<a href="<?php echo HOME_URI;?>/eventos/index/editar/<?php echo chk_array($parametros, 1); ?>" class="btn btn-block btn-primary btn-sm">Editar Evento</a>
								<?php } ?>
							</div>
						</div>
						

					</div>
                </div>
            </section>
        </div>
		
		<script>
		$(document).ready(function(){
			$("#comprovante").uploadFile({
				url: "<?php echo HOME_URI; ?>/eventos/upload/index/financeiro/?opcao=upload",
				dragDrop: true,
				multiple: false,
				maxFileCount: 1,
				fileName: "midia",
				returnType: "json",
				allowedTypes: "jpeg, jpg, gif, png, pdf, doc, docx, xls, xlsx, csv, ppt, pptx",
				showDelete: true,
				showDownload: false,
				maxFileSize: 5000*1024,
				showPreview: true,
				previewWidth: "100px",
				dragDropStr: "<span><strong>Arraste e Solte o arquivo aqui</strong></span>",
				abortStr: "Cancelar",
				cancelStr: "Cancelar",
				doneStr: "Pronto",
				multiDragErrorStr: "Não é permitido mais do que um arquivo.",
				extErrorStr: " não é permitido, formatos permitidos: ",
				sizeErrorStr: "não pode ser enviado, tamanho máximo permitido: ",
				uploadErrorStr: "Upload não permitido",
				uploadStr: "Enviar",
				deletelStr: "Remover",
				maxFileCountErrorStr: "não pode ser enviado, o remova primeiro o arquivo existente, número máximo de arquivos permitidos: ",
				duplicateErrorStr: "não pode ser enviado, já existe um arquivo com o mesmo nome.",

				onLoad:function(obj){
					$.ajax({
						cache: false,
						url: "<?php echo HOME_URI;?>/eventos/upload/index/financeiro/",
						dataType: "json",
						success: function(data){
							for(var i = 0; i< data.length; i++){ 
								obj.createProgress(data[i]["name"],data[i]["path"],data[i]["size"]);
							}
						}
					});
				},
				deleteCallback: function (data, pd) {
					for (var i = 0; i < data.length; i++) {
						$.post("<?php echo HOME_URI;?>/eventos/upload/index/financeiro/", 
							{
								opcao: "delete",
								name: data[i]
							}
						);
					}
					
					pd.statusbar.hide();
				}
			});
		});
		</script>