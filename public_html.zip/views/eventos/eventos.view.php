<?php 
if(!defined('ABSPATH')) exit; 

	if($this->check_permissions('evento-remover', $this->userdata['modulo'])){
		$modelo->removerEvento($parametros);
	}

	if($this->check_permissions('evento-bloquear', $this->userdata['modulo']) && $this->check_permissions('evento-desbloquear', $this->userdata['modulo'])){
		if(chk_array($this->parametros, 0) == 'bloquear'){
			$modelo->bloquearEvento();
		}

		if(chk_array($this->parametros, 0) == 'desbloquear'){
			$modelo->desbloquearEvento();
		}
	}

	// $categorias = $modeloCategorias->getCategorias(); 
	// $clientes = $modeloClientes->getClientes(); 
	// $locais = $modeloLocais->getLocais(); 
	// $fases = $modeloFases->getFases(); 

	$dataInicioFim = isset($_REQUEST["dataInicioFim"]) ? $_REQUEST["dataInicioFim"] : null;
	$categoria = isset($_REQUEST["categoria"]) ? $_REQUEST["categoria"] : null;
	$cliente = isset($_REQUEST["cliente"]) ? $_REQUEST["cliente"] : null;
	$lider = isset($_REQUEST["lider"]) ? $_REQUEST["lider"] : null;
	$local = isset($_REQUEST["local"]) ? $_REQUEST["local"] : null;
	$fase = isset($_REQUEST["fase"]) ? $_REQUEST["fase"] : null;
	$q = isset($_REQUEST["q"]) ? $_REQUEST["q"] : null;
	
	if($this->userdata['idPermissao'] == 3){
		$lider = $this->userdata['id'];
	}

	$filtros = array('dataInicioFim' => $dataInicioFim, 'categoria' => $categoria, 'cliente' => $cliente, 'lider' => $lider, 'local' => $local, 'fase' => $fase, 'q' => $q);
	
	$eventos = $modelo->getEventos($filtros); 

?>
        <div class="content-wrapper">
			<section class="content-header">
                <h1>Eventos<small>&nbsp;</small></h1>
                
				<ol class="breadcrumb">
                    <li><a href="<?php echo HOME_URI; ?>"><i class="fa fa-dashboard"></i> Painel</a></li>
                    <li class="active"><a href="<?php echo HOME_URI; ?>/eventos">Eventos</a></li>
                </ol>
            </section>
			
            <section class="content">
				<?php if($this->userdata['idPermissao'] < 4){ ?>
				<div class="row">
					<div class="col-md-12">
                        <div class="box box-danger collapsed-box">
                            <div class="box-header with-border" data-widget="collapse">
								<i class="fa fa-filter"></i>
                                <h3 class="box-title">Busca com filtros</h3>
                            </div>

                            <form role="form" action="" method="POST" enctype="multipart/form-data">
                                <div class="box-body">
									<div class="row">
									
										<div class="col-md-3">
											<label for="dataInicioFim">Data</label>
											<div class="input-group">
												<div class="input-group-addon">
													<i class="fa fa-calendar"></i>
												</div>
												<input type="text" class="form-control pull-right dateRangePicker" id="dataInicioFim" name="dataInicioFim" value="<?php echo $dataInicioFim; ?>">
											</div>
										</div>
										
										<div class="col-md-3">
											<div class="form-group">
												<label for="categoria">Categoria</label>
												
												<select class="form-control select2" name="categoria" id="categoria">
													<option value="">Escolha uma opção</option>
													<?php
													foreach($categorias AS $dadosCategorias):
														echo"<option value='" . $dadosCategorias['id'] . "' ";
														if($categoria == $dadosCategorias['id']){ echo'selected'; }
														echo">" . $dadosCategorias['categoria'] . "</option>";
													endforeach;
													?>
												</select>
											</div>
										</div>
										
										
										<div class="col-md-3">
											<div class="form-group">
												<label for="cliente">Cliente</label>
												<select class="form-control select2" name="cliente" id="cliente">
													<option value="">Escolha</option>
													<?php
													foreach($clientes AS $dadosClientes):
														echo"<option value='" . $dadosClientes['idPessoa'] . "' ";
														if($cliente == $dadosClientes['idPessoa']){ echo'selected'; }
														echo">" . $dadosClientes['nomeFantasia'] . "</option>";
													endforeach;
													?>
												</select>
											</div>
										</div>
		
										<?php
										$lideres = $modeloUsuarios->getUsuarios(array('hierarquia' => 3)); 
										?>
										<div class="col-md-3">
											<div class="form-group">
												<div class="form-group">
													<label for="lider">Gerente</label>
													<select class="form-control select2" name="lider" id="lider">
														<option value="">Escolha uma opção</option>
														<?php
														foreach($lideres AS $dadosLideres):
															echo"<option value='" . $dadosLideres['idPessoa'] . "' ";
															if($lider == $dadosLideres['idPessoa']){ echo'selected'; }
															echo">" . $dadosLideres['nome'] . " " . $dadosLideres['sobrenome'] . "</option>";
														endforeach;
														?>
													</select>
												</div>
											</div>
										</div>
										
									</div>
									<div class="row">

										<div class="col-md-3">
											<div class="form-group">
												<label for="local">Local</label>
												<select class="form-control select2" name="local" id="local">
													<option value="">Escolha</option>
													<?php
													foreach($locais AS $dadosLocais):
														echo"<option value='" . $dadosLocais['id'] . "' ";
														if($local == $dadosLocais['id']){ echo'selected'; }
														echo">" . $dadosLocais['titulo'] . "</option>";
													endforeach;
													?>
												</select>
											</div>
										</div>
							
										<div class="col-md-6">
											<div class="form-group">
												<label for="q">Busca por texto</label>
												<input type="text" class="form-control" placeholder="Digite aqui..." name="q" id="q" value="<?php echo $q; ?>">
											</div>
										</div>

									</div>

								</div>
								
                                <div class="box-footer">
									<button type="submit" class="btn btn-primary">Buscar</button>
									<a href="<?php echo HOME_URI; ?>/eventos" class="btn btn-primary">Limpar</a>
                                </div>
                            </form>
						
                        </div>
                    </div>
				</div>
				<?php } ?>
				
                <div class="row">
					<div class="col-xs-12">
                        <div class="box">
                            <div class="box-header">
								<i class="fa fa-list"></i>
                                <h3 class="box-title">Eventos cadastrados</h3>
                            </div>

                            <div class="box-body">
								
								<?php 
								echo $modelo->form_msg;
								?>
								
                                 <table id="table" class="table table-hover table-bordered table-striped dataTable">
                                    <thead>
                                        <tr>
                                            <th>Data</th>
                                            <th>Evento</th>
											<?php if($this->check_permissions('evento-contratacao', $this->userdata['modulo'])){?>
											<th>Nº Contratados</th>
											<?php } ?>
											<?php if($this->userdata['idPermissao'] < 4){ ?>
                                            <th>Cliente</th>
											<?php } ?>
											<?php if($this->userdata['idPermissao'] < 3){ ?>
											<th>Verba</th>
											<?php } ?>
											<th>Opções</th>
                                        </tr>
                                    </thead>
									
                                    <tbody>
										<?php 
										foreach($eventos AS $dados): 
											if($this->userdata['idPermissao'] == 4){
												$dados['id'] = $dados['idEvento'];
												$dados['dataInicio'] = $dados['dataInicioEvento'];
												$dados['dataFim'] = $dados['dataFimEvento'];
											}
										?>
										<tr>
											<td>
												<?php
												$dataInicial = explode("-", $dados['dataInicio']);
												$dataFinal = explode("-", $dados['dataFim']);
												 
												if($dados['dataInicio'] == $dados['dataFim']){
													echo $dataInicial[2] . " " . mesAbreviado($dataInicial[1]) . "/" . $dataInicial[0];
												}else{
													echo $dataInicial[2] . " " . mesAbreviado($dataInicial[1]) . "/" . $dataInicial[0] . " - " . $dataFinal[2] . " " . mesAbreviado($dataFinal[1]) . "/" . $dataFinal[0];
												}
												?>
											</td>
											
                                            <td><a href="<?php echo HOME_URI;?>/eventos/index/perfil/<?php echo $dados['id']; ?>"><?php echo $dados['evento']; ?></a></td>

											<?php if($this->check_permissions('evento-contratacao', $this->userdata['modulo'])){?>
											<td><?php echo count($modeloEventoContratacoes->getContratacoes(null, null, $dados['id'])); ?></td>
											<?php } ?>
                                            
											<?php if($this->userdata['idPermissao'] < 4){ ?>
											<td><a href="<?php echo HOME_URI;?>/clientes/index/perfil/<?php echo $dados['idCliente']; ?>"><?php echo $dados['nomeFantasia']; ?></a></td>
											<?php } ?>
											
											<?php if($this->userdata['idPermissao'] < 3){ ?>
											<td><?php echo number_format(($dados['verba'] - $dados['escritorio']), 2, ',', '.') ; ?></td>
											<?php } ?>
											
											<td>
												<a href="<?php echo HOME_URI;?>/eventos/index/perfil/<?php echo $dados['id']; ?>" class="icon-tab" title="Perfil"><i class="fa fa-eye fa-lg "></i></a>&nbsp; &nbsp; &nbsp;
												<?php if($this->check_permissions('evento-contratacao', $this->userdata['modulo'])){?>
												<a href="<?php echo HOME_URI;?>/eventos/index/contratacoes/<?php echo $dados['id']; ?>" class="icon-tab" title="Contratações"><i class="fa fa-user fa-lg "></i></a>&nbsp; &nbsp; &nbsp;
												<?php } ?>
												
												<?php if($this->check_permissions('evento-editar', $this->userdata['modulo'])){?>
												<a href="<?php echo HOME_URI; ?>/eventos/index/editar/<?php echo $dados['id']; ?>" class="icon-tab" title="Editar"><i class="fa fa-pencil-square-o  fa-lg"></i></a>&nbsp; &nbsp; &nbsp;
												<?php } ?>
											</td>
                                        </tr>
										<?php endforeach; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <th>Data</th>
                                            <th>Evento</th>
											<?php if($this->check_permissions('evento-contratacao', $this->userdata['modulo'])){?>
											<th>Nº Contratados</th>
											<?php } ?>
											<?php if($this->userdata['idPermissao'] < 4){ ?>
                                            <th>Cliente</th>
											<?php } ?>
											<?php if($this->userdata['idPermissao'] < 3){ ?>
											<th>Verba</th>
											<?php } ?>
											<th>Opções</th>
                                        </tr>
                                    </tfoot>
                                </table>

                            </div>
                        </div>
                    </div>
				</div>
				
				<div class="row">
					<div class="col-md-2">
						<?php if($this->check_permissions('evento-adicionar', $this->userdata['modulo'])){?>
						<a href="<?php echo HOME_URI;?>/eventos/index/adicionar"><button type="button" class="btn btn-block btn-danger">Adicionar Evento</button></a>
						<?php } ?>
					</div>
                </div>
            </section>
        </div>