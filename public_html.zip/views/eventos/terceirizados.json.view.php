<?php 
if(!defined('ABSPATH')) exit; 

header('content-type: application/json; charset=utf-8');
header("access-control-allow-origin: *");

$resultado = null;

$id = $_REQUEST['id'];

$terceirizados = $modelo->getTerceirizados($id); 
if(count($terceirizados) > 0){
	foreach($terceirizados AS $dados):
		$resultado[] = array(
				"chave" => $dados['idPessoa'],
				"valor" => $dados['nome'] . " " . $dados['sobrenome']
			);
	endforeach;
}
	
echo json_encode($resultado);	
?>