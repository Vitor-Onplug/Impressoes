<?php
class EventosController extends MainController {
	public $login_required = true;

    public function index(){
		$this->title = SYS_NAME . ' - Eventos';
		
		if (!$this->logged_in){
			$this->logout();
			
			$this->goto_login();
			
			return;
		}
		
		$parametros = (func_num_args() >= 1) ? func_get_arg(0) : array();
		
		$modelo = $this->load_model('eventos/eventos');
		//$modeloCategorias = $this->load_model('eventos/categorias');
		//$modeloLocais = $this->load_model('eventos/locais');
		//$modeloContratacoes = $this->load_model('eventos/contratacoes');

		$modeloUsuarios = $this->load_model('usuarios/usuarios');
		//$modeloParceiros = $this->load_model('parceiros/parceiros');
		
		if(chk_array($this->parametros, 0) == 'adicionar'){
			if(!$this->check_permissions('evento-adicionar', $this->userdata['modulo'])){
				require_once ABSPATH . '/views/permission.view.php';
				
				return;
			}
			
			$this->title = SYS_NAME . ' - Adicionar Evento';
			
			$conteudo = ABSPATH . '/views/eventos/form.view.php';
		}elseif(chk_array($this->parametros, 0) == 'editar'){
			if(!$this->check_permissions('evento-editar', $this->userdata['modulo'])){
				require_once ABSPATH . '/views/permission.view.php';
				
				return;
			}
			
			$this->title = SYS_NAME . ' - Editar Evento';
			
			$conteudo = ABSPATH . '/views/eventos/form.view.php';
		}else{
			$conteudo = ABSPATH . '/views/eventos/eventos.view.php';
		}
		
		require ABSPATH . '/views/painel/painel.view.php';
    }
	
	public function json(){
		if (!$this->logged_in){
			$this->logout();
			
			$this->goto_login();
			
			return;
		}
		
		$parametros = (func_num_args() >= 1) ? func_get_arg(0) : array();
		
		if(chk_array($this->parametros, 0) == 'terceirizados'){
			$modelo = $this->load_model('eventos/contratacoes');
		
			require ABSPATH . '/views/eventos/terceirizados.json.view.php';
		}
	}
	
	public function upload(){
		$parametros = (func_num_args() >= 1) ? func_get_arg(0) : array();
	
        $modelo = $this->load_model('eventos/upload');
	
		require ABSPATH . '/views/eventos/upload.view.php';
	}
}